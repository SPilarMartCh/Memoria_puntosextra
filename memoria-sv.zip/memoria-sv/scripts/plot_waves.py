#!/usr/bin/env python3
"""Dibuja las formas de onda principales de build/tb_memory_top.vcd en docs/waveform.png.

Uso:  python3 scripts/plot_waves.py [vcd] [png] [t_fin_ns]
"""
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

VCD = sys.argv[1] if len(sys.argv) > 1 else "build/tb_memory_top.vcd"
PNG = sys.argv[2] if len(sys.argv) > 2 else "docs/waveform.png"
T_END = float(sys.argv[3]) if len(sys.argv) > 3 else 60.0

WANT = ["address", "write_enable", "read_enable", "data"]


def parse_vcd(path):
    ids, scope, changes, t, ts_ps = {}, [], {}, 0, 1000
    with open(path) as f:
        for line in f:
            tok = line.split()
            if not tok:
                continue
            if tok[0] == "$timescale":
                pass
            elif tok[0] == "$scope":
                scope.append(tok[2])
            elif tok[0] == "$upscope":
                scope.pop()
            elif tok[0] == "$var":
                name = tok[4]
                if scope == ["tb_memory_top"] and name in WANT and tok[3] not in ids:
                    ids[tok[3]] = name
                    changes[name] = []
            elif tok[0].startswith("#"):
                t = int(tok[0][1:]) / ts_ps
            elif tok[0][0] in "bB":
                if tok[1] in ids:
                    changes[ids[tok[1]]].append((t, tok[0][1:]))
            elif tok[0][0] in "01xzXZ" and len(tok[0]) > 1:
                if tok[0][1:] in ids:
                    changes[ids[tok[0][1:]]].append((t, tok[0][0]))
    return changes


def main():
    ch = parse_vcd(VCD)
    fig, ax = plt.subplots(figsize=(12, 3.6))
    y = 0
    labels = []
    for name in reversed(WANT):
        ev = [(t, v) for t, v in ch.get(name, []) if t <= T_END]
        ev.append((T_END, ev[-1][1] if ev else "x"))
        if name in ("write_enable", "read_enable"):
            xs, ys = [], []
            for (t0, v), (t1, _) in zip(ev, ev[1:]):
                lvl = 0.8 if v == "1" else 0.1
                xs += [t0, t1]
                ys += [y + lvl, y + lvl]
            ax.plot(xs, ys, color="#2a6fdb", lw=2)
        else:
            for (t0, v), (t1, _) in zip(ev, ev[1:]):
                if t1 <= t0:
                    continue
                is_z = set(v.lower()) <= {"z"}
                col = "#bbbbbb" if is_z else "#1f9d55"
                ax.fill_between([t0 + 0.3, t1 - 0.3], y + 0.1, y + 0.8,
                                color=col, alpha=0.35, lw=0)
                txt = "Z" if is_z else v
                if t1 - t0 > 3:
                    ax.text((t0 + t1) / 2, y + 0.45, txt, ha="center",
                            va="center", fontsize=8, family="monospace")
        labels.append((y + 0.45, name))
        y += 1
    ax.set_yticks([p for p, _ in labels])
    ax.set_yticklabels([n for _, n in labels], family="monospace")
    ax.set_xlabel("tiempo (ns)")
    ax.set_xlim(0, T_END)
    ax.set_title("memory_top: escritura de 10111100 en 1001 y lectura posterior")
    ax.grid(axis="x", alpha=0.3)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(PNG, dpi=150)
    print("guardado", PNG)


if __name__ == "__main__":
    main()
