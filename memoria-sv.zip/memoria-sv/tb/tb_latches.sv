// ============================================================================
// tb_latches.sv
// Prueba los bloques básicos: AND-OR latch, gated latch y registro.
// ============================================================================
`timescale 1ns/1ps

module tb_latches;

    int errors = 0;

    task automatic check(input string what, input logic got, input logic exp);
        if (got !== exp) begin
            $display("  [FALLA] %s: obtenido=%b esperado=%b", what, got, exp);
            errors++;
        end else
            $display("  [OK]    %s = %b", what, got);
    endtask

    // ---------------- AND-OR latch ----------------
    logic s, r, q_sr;
    and_or_latch dut_sr (.set(s), .reset(r), .q(q_sr));

    // ---------------- Gated latch -----------------
    logic d, we, q_gl;
    gated_latch dut_gl (.data(d), .write_enable(we), .q(q_gl));

    // ---------------- Registro de 8 bits ----------
    logic [7:0] rd, rq;
    logic       rwe;
    register #(.WIDTH(8)) dut_reg (.d(rd), .write_enable(rwe), .q(rq));

    initial begin
        $dumpfile("build/tb_latches.vcd");
        $dumpvars(0, tb_latches);

        $display("\n== AND-OR latch ==");
        s = 0; r = 0; #5;
        s = 1;     #5; check("SET=1 -> Q", q_sr, 1'b1);
        s = 0;     #5; check("SET vuelve a 0, Q se mantiene", q_sr, 1'b1);
        r = 1;     #5; check("RESET=1 -> Q", q_sr, 1'b0);
        r = 0;     #5; check("RESET vuelve a 0, Q se mantiene", q_sr, 1'b0);

        $display("\n== Gated latch ==");
        d = 1; we = 0; #5;
        we = 1;    #5; check("WE=1, DATA=1 -> Q", q_gl, 1'b1);
        we = 0;    #5;
        d = 0;     #5; check("WE=0, DATA cambia a 0 -> Q no cambia", q_gl, 1'b1);
        we = 1;    #5; check("WE=1, DATA=0 -> Q", q_gl, 1'b0);
        we = 0; d = 1; #5; check("WE=0, DATA=1 -> Q sigue en 0", q_gl, 1'b0);

        $display("\n== Registro de 8 bits (92 = 01011100) ==");
        rd = 8'd92; rwe = 0; #5;
        rwe = 1; #5; rwe = 0; #5;
        rd = 8'hFF; #5;   // el dato de entrada cambia, pero WE = 0
        if (rq !== 8'd92) begin
            $display("  [FALLA] registro = %b, esperado 01011100", rq); errors++;
        end else
            $display("  [OK]    registro = %b (%0d)", rq, rq);

        $display("\n== Resultado: %0d errores ==", errors);
        if (errors == 0) $display("PASS tb_latches");
        else             $display("FAIL tb_latches");
        $finish;
    end

endmodule
