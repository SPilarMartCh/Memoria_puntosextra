// ============================================================================
// tb_memory_top.sv
// Testbench autoverificable para memory_top (parametrizable desde la línea
// de comandos, p. ej. -P tb_memory_top.DATA_WIDTH=16 -P tb_memory_top.ADDR_WIDTH=6).
//
// Pruebas:
//   1. Ejemplo del video: escribir 10111100 en la dirección 1001 y leerlo.
//   2. Bus en alta impedancia cuando READ_ENABLE = 0.
//   3. Escribir un valor distinto en TODAS las direcciones y leerlas todas.
//   4. Sobrescribir una dirección sin afectar a sus vecinas.
//   5. "LOAD R0 1001": leer un byte de memoria y guardarlo en un registro.
// ============================================================================
`timescale 1ns/1ps

module tb_memory_top;

    parameter int DATA_WIDTH = 8;
    parameter int ADDR_WIDTH = 4;
    localparam int DEPTH = 1 << ADDR_WIDTH;

    // Señales hacia la memoria
    logic [ADDR_WIDTH-1:0] address;
    logic                  write_enable;
    logic                  read_enable;
    wire  [DATA_WIDTH-1:0] data;

    // El testbench maneja el bus sólo al escribir (tri-estado)
    logic [DATA_WIDTH-1:0] tb_data;
    logic                  tb_drive;
    assign data = tb_drive ? tb_data : 'z;

    // Modelo de referencia
    logic [DATA_WIDTH-1:0] golden [DEPTH];

    int errors = 0;

    memory_top #(
        .DATA_WIDTH (DATA_WIDTH),
        .ADDR_WIDTH (ADDR_WIDTH)
    ) dut (
        .address      (address),
        .write_enable (write_enable),
        .read_enable  (read_enable),
        .data         (data)
    );

    // Registro tipo CPU para la prueba LOAD R0 <addr>
    logic [DATA_WIDTH-1:0] r0;
    logic                  r0_we;
    register #(.WIDTH(DATA_WIDTH)) u_r0 (.d(data), .write_enable(r0_we), .q(r0));

    // ------------------------------------------------------------------
    // Operaciones de bus (secuencia segura para latches: la dirección y el
    // dato se estabilizan ANTES de activar WE, y WE baja ANTES de cambiarlos)
    // ------------------------------------------------------------------
    task automatic mem_write(input logic [ADDR_WIDTH-1:0] a,
                             input logic [DATA_WIDTH-1:0] d);
        read_enable = 0;
        address  = a;
        tb_data  = d;
        tb_drive = 1;
        #5 write_enable = 1;
        #5 write_enable = 0;
        #5 tb_drive = 0;
        golden[a] = d;
    endtask

    task automatic mem_read(input  logic [ADDR_WIDTH-1:0] a,
                            output logic [DATA_WIDTH-1:0] d);
        tb_drive    = 0;
        address     = a;
        #5 read_enable = 1;
        #5 d = data;
        read_enable = 0;
        #5;
    endtask

    task automatic expect_read(input logic [ADDR_WIDTH-1:0] a);
        logic [DATA_WIDTH-1:0] got;
        mem_read(a, got);
        if (got !== golden[a]) begin
            $display("  [FALLA] dir %b: leído %b, esperado %b", a, got, golden[a]);
            errors++;
        end
    endtask

    initial begin
        logic [DATA_WIDTH-1:0] v;
        logic [ADDR_WIDTH-1:0] ex_addr;

        $dumpfile("build/tb_memory_top.vcd");
        $dumpvars(0, tb_memory_top);

        $display("\n=== memory_top  DATA_WIDTH=%0d  ADDR_WIDTH=%0d  (%0d palabras) ===",
                 DATA_WIDTH, ADDR_WIDTH, DEPTH);

        address = '0; write_enable = 0; read_enable = 0;
        tb_drive = 0; tb_data = '0; r0_we = 0;
        #10;

        // 1. Ejemplo del video ------------------------------------------
        ex_addr = ADDR_WIDTH'(9);                 // 1001
        mem_write(ex_addr, DATA_WIDTH'(8'b10111100));
        mem_read(ex_addr, v);
        if (v !== golden[ex_addr]) begin
            $display("  [FALLA] ejemplo del video: %b", v); errors++;
        end else
            $display("  [OK] Prueba 1: dir %b contiene %b", ex_addr, v);

        // 2. Alta impedancia ---------------------------------------------
        #5;
        if (data !== {DATA_WIDTH{1'bz}}) begin
            $display("  [FALLA] el bus no está en 'z' con RE=0: %b", data); errors++;
        end else
            $display("  [OK] Prueba 2: con READ_ENABLE=0 el bus queda en %b", data);

        // 3. Todas las direcciones ---------------------------------------
        for (int i = 0; i < DEPTH; i++)
            mem_write(ADDR_WIDTH'(i), DATA_WIDTH'($urandom));
        for (int i = 0; i < DEPTH; i++)
            expect_read(ADDR_WIDTH'(i));
        $display("  [%s] Prueba 3: escritura/lectura de las %0d direcciones",
                 errors == 0 ? "OK" : "!!", DEPTH);

        // 4. Sobrescritura aislada ---------------------------------------
        mem_write(ex_addr, ~golden[ex_addr]);
        for (int i = 0; i < DEPTH; i++)
            expect_read(ADDR_WIDTH'(i));
        $display("  [%s] Prueba 4: sobrescribir dir %b no altera las demás",
                 errors == 0 ? "OK" : "!!", ex_addr);

        // 5. LOAD R0 1001 ------------------------------------------------
        address = ex_addr;
        #5 read_enable = 1;       // la memoria pone el byte en el bus
        #5 r0_we = 1;             // el registro R0 lo captura
        #5 r0_we = 0;
        #5 read_enable = 0;
        #5;
        if (r0 !== golden[ex_addr]) begin
            $display("  [FALLA] LOAD R0: R0=%b, esperado %b", r0, golden[ex_addr]); errors++;
        end else
            $display("  [OK] Prueba 5: LOAD R0 %b -> R0 = %b", ex_addr, r0);

        $display("\n=== Resultado: %0d errores ===", errors);
        if (errors == 0) $display("PASS tb_memory_top");
        else             $display("FAIL tb_memory_top");
        $finish;
    end

endmodule
