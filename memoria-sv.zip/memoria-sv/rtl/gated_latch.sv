// ============================================================================
// gated_latch.sv
// ----------------------------------------------------------------------------
// Nivel 2 del video: el "Gated Latch" (latch con habilitación de escritura).
//
// El AND-OR latch necesita dos señales (SET y RESET). Para guardar un dato
// con una sola línea se agrega lógica de entrada:
//
//   SET   = DATA  & WRITE_ENABLE
//   RESET = ~DATA & WRITE_ENABLE
//
//   * WRITE_ENABLE = 0  -> SET = RESET = 0 -> el latch conserva su valor.
//   * WRITE_ENABLE = 1  -> la salida copia DATA (1 -> SET, 0 -> RESET).
//
// Así nunca se activan SET y RESET al mismo tiempo.
// ============================================================================
`timescale 1ns/1ps

module gated_latch (
    input  logic data,          // D_in
    input  logic write_enable,  // WE
    output logic q              // D_out (bit almacenado)
);
    logic data_n;
    logic set, reset;

    not u_inv  (data_n, data);
    and u_set  (set,   data,   write_enable);
    and u_rst  (reset, data_n, write_enable);

    and_or_latch u_latch (
        .set   (set),
        .reset (reset),
        .q     (q)
    );

endmodule
