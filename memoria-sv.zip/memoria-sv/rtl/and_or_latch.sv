// ============================================================================
// and_or_latch.sv
// ----------------------------------------------------------------------------
// Nivel 1 del video: el "AND-OR latch".
//
//   - Una compuerta OR cuya salida se realimenta a una de sus entradas
//     "recuerda" un 1 para siempre (OR latch): una vez que SET = 1, la salida
//     queda en 1 aunque SET vuelva a 0.
//   - Para poder volver a 0 se agrega una compuerta AND a la salida, con la
//     entrada RESET invertida. Si RESET = 1, la AND fuerza la salida a 0 y,
//     al estar realimentada, el 0 también se mantiene.
//
//          SET ──┐
//                OR ──┐
//          ┌─────┘    AND ──┬──► Q
//  RESET ─►NOT ───────┘     │
//          └────────────────┘   (realimentación)
//
//   Q(siguiente) = (Q | SET) & ~RESET
//
// Se modela a nivel de compuertas (lazo combinacional real), exactamente como
// el circuito del video. No es un flip-flop: es sensible a nivel.
// ============================================================================
`timescale 1ns/1ps

module and_or_latch (
    input  logic set,
    input  logic reset,
    output logic q
);
    logic or_out;
    logic not_reset;

    // Compuertas explícitas (primitivas de Verilog) para mostrar el circuito.
    or  u_or  (or_out, q, set);         // OR con realimentación de Q
    not u_not (not_reset, reset);       // RESET invertido
    and u_and (q, or_out, not_reset);   // AND que permite borrar el bit

endmodule
