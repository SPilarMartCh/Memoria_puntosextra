// ============================================================================
// memory_cell.sv
// ----------------------------------------------------------------------------
// Una celda de la matriz: un gated latch + la lógica de selección + el
// "transistor" de lectura (buffer tri-estado).
//
//                   row_sel ─┐
//                   col_sel ─┼─ AND ── sel
//                            │
//   write_enable ── AND(sel) ┴──► WE del gated latch
//   read_enable  ── AND(sel) ───► control del transistor de salida
//
//   D_in/out (línea compartida) ──► D_in  [GATED LATCH]  D_out ──► transistor ──► D_in/out
//
// * La celda sólo está seleccionada cuando su cable de fila Y su cable de
//   columna están activos (intersección en la cuadrícula).
// * Escritura: sel & WE  -> el latch copia el valor de la línea D_in/out.
// * Lectura:   sel & RE  -> el transistor conduce y el bit guardado se
//   coloca en la línea D_in/out. Si no, la salida queda en alta impedancia
//   (1'bz) para no interferir con las demás celdas que comparten la línea.
// ============================================================================
`timescale 1ns/1ps

module memory_cell (
    input  logic row_sel,
    input  logic col_sel,
    input  logic write_enable,
    input  logic read_enable,
    inout  wire  data_io          // línea D_in/out compartida por toda la matriz
);
    logic sel;
    logic cell_we;
    logic cell_re;
    logic stored_bit;

    and u_sel (sel,     row_sel, col_sel);
    and u_we  (cell_we, sel,     write_enable);
    and u_re  (cell_re, sel,     read_enable);

    gated_latch u_latch (
        .data         (data_io),
        .write_enable (cell_we),
        .q            (stored_bit)
    );

    // "Transistor" de salida: buffer tri-estado.
    bufif1 u_tx (data_io, stored_bit, cell_re);

endmodule
