// ============================================================================
// memory_top.sv   (MÓDULO TOP)
// ----------------------------------------------------------------------------
// Nivel 5 del video: memoria de palabras (bytes) parametrizada.
//
// Se apilan DATA_WIDTH matrices de 1 bit. Todas comparten la MISMA dirección,
// WRITE_ENABLE y READ_ENABLE; cada matriz aporta un bit de la palabra.
// Desde fuera la memoria se ve como una lista de palabras numeradas:
//
//        Data Bus  (DATA_WIDTH líneas bidireccionales)
//        Address Bus (ADDR_WIDTH líneas)  ──►  2^ADDR_WIDTH palabras
//        Write Enable, Read Enable
//
// La dirección se divide en dos mitades:
//   address[ADDR_WIDTH-1 : COL_BITS] -> decodificador de FILAS
//   address[COL_BITS-1   : 0]        -> decodificador de COLUMNAS
//
// Parámetros:
//   DATA_WIDTH : bits por palabra (8 = byte, como en el video).
//   ADDR_WIDTH : bits de dirección. Capacidad = 2^ADDR_WIDTH palabras
//                (4 -> 16 bytes como en el video; 32 -> 4 294 967 296 bytes).
//
// Operación (asíncrona, sensible a nivel, igual que los latches del video):
//   Escritura: poner address y data, luego pulsar write_enable (read_enable=0).
//   Lectura  : poner address, read_enable = 1; la memoria maneja data.
//   Reposo   : read_enable = 0 -> data queda en alta impedancia ('z).
// ============================================================================
`timescale 1ns/1ps

module memory_top #(
    parameter int DATA_WIDTH = 8,
    parameter int ADDR_WIDTH = 4
) (
    input  logic [ADDR_WIDTH-1:0] address,
    input  logic                  write_enable,
    input  logic                  read_enable,
    inout  wire  [DATA_WIDTH-1:0] data          // bus de datos bidireccional
);
    // ------------------------------------------------------------------
    // División de la dirección en fila / columna
    // ------------------------------------------------------------------
    localparam int COL_BITS = ADDR_WIDTH / 2;
    localparam int ROW_BITS = ADDR_WIDTH - COL_BITS;
    localparam int ROWS     = 1 << ROW_BITS;
    localparam int COLS     = 1 << COL_BITS;
    localparam int DEPTH    = 1 << ADDR_WIDTH;   // número de palabras

    logic [ROWS-1:0] row_sel;
    logic [COLS-1:0] col_sel;

    // ------------------------------------------------------------------
    // Decodificadores binarios (compartidos por todas las matrices,
    // porque todas reciben la misma dirección)
    // ------------------------------------------------------------------
    binary_decoder #(.N(ROW_BITS)) u_row_dec (
        .in     (address[ADDR_WIDTH-1 -: ROW_BITS]),
        .enable (1'b1),
        .out    (row_sel)
    );

    generate
        if (COL_BITS > 0) begin : g_coldec
            binary_decoder #(.N(COL_BITS)) u_col_dec (
                .in     (address[COL_BITS-1:0]),
                .enable (1'b1),
                .out    (col_sel)
            );
        end else begin : g_nocol
            assign col_sel = 1'b1;   // ADDR_WIDTH = 1: una sola columna
        end
    endgenerate

    // ------------------------------------------------------------------
    // DATA_WIDTH matrices de 1 bit apiladas (una por bit del bus)
    // ------------------------------------------------------------------
    genvar b;
    generate
        for (b = 0; b < DATA_WIDTH; b++) begin : g_plane
            memory_matrix #(
                .ROWS (ROWS),
                .COLS (COLS)
            ) u_matrix (
                .row_sel      (row_sel),
                .col_sel      (col_sel),
                .write_enable (write_enable),
                .read_enable  (read_enable),
                .data_io      (data[b])
            );
        end
    endgenerate

    // ------------------------------------------------------------------
    // Verificación de parámetros
    // ------------------------------------------------------------------
    initial begin
        if (DATA_WIDTH < 1) $fatal(1, "DATA_WIDTH debe ser >= 1");
        if (ADDR_WIDTH < 1) $fatal(1, "ADDR_WIDTH debe ser >= 1");
    end

endmodule
