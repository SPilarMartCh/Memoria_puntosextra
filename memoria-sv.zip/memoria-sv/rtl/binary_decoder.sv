// ============================================================================
// binary_decoder.sv
// ----------------------------------------------------------------------------
// Decodificador binario N -> 2^N (salida one-hot).
//
// Con N bits de entrada activa exactamente UNA de sus 2^N salidas: la salida
// cuyo índice es el número binario de entrada. En la memoria se usa uno para
// seleccionar la FILA y otro para seleccionar la COLUMNA de la matriz.
//
//   in = 2'b10  ->  out = 4'b0100   (Output_2 activo)
//
// Opcionalmente tiene "enable": si enable = 0 ninguna salida se activa.
// ============================================================================
`timescale 1ns/1ps

module binary_decoder #(
    parameter int N = 2              // bits de entrada
) (
    input  logic [N-1:0]      in,
    input  logic              enable,
    output logic [(1<<N)-1:0] out
);
    genvar k;
    generate
        for (k = 0; k < (1 << N); k++) begin : g_out
            // Cada salida es una AND de los bits de entrada (directos o
            // invertidos) que forman el número k.
            assign out[k] = enable & (in == k);
        end
    endgenerate

endmodule
