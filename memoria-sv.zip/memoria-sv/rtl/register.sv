// ============================================================================
// register.sv
// ----------------------------------------------------------------------------
// Nivel 3 del video: el registro.
//
// WIDTH gated latches en paralelo que comparten UNA sola línea de
// WRITE_ENABLE. Cada latch guarda un bit; al activar WE se captura la palabra
// completa (por ejemplo 92 decimal = 01011100 en un registro de 8 bits).
//
// Es lo que usa el CPU para sus registros de propósito general (Reg_A, ...)
// y el registro de instrucción. Su problema: necesita WIDTH cables de entrada
// y WIDTH de salida, por lo que no escala para guardar mucha información.
// Esa es la motivación de la matriz de memoria (memory_matrix.sv).
// ============================================================================
`timescale 1ns/1ps

module register #(
    parameter int WIDTH = 8
) (
    input  logic [WIDTH-1:0] d,
    input  logic             write_enable,
    output logic [WIDTH-1:0] q
);
    genvar i;
    generate
        for (i = 0; i < WIDTH; i++) begin : g_bit
            gated_latch u_bit (
                .data         (d[i]),
                .write_enable (write_enable),
                .q            (q[i])
            );
        end
    endgenerate

endmodule
