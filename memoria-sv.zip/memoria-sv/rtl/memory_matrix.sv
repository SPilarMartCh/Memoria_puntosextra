// ============================================================================
// memory_matrix.sv
// ----------------------------------------------------------------------------
// Nivel 4 del video: la matriz de latches (un "plano" de 1 bit).
//
// En lugar de dar cables propios a cada latch, se acomodan en una cuadrícula
// de ROWS x COLS. Cada celda queda en la intersección de un cable de fila y
// uno de columna; activar una fila y una columna señala UNA sola celda.
//
//   * Un decodificador de filas (ROW_BITS -> ROWS) y uno de columnas
//     (COL_BITS -> COLS) convierten la dirección en cables de fila/columna.
//   * Todas las celdas comparten las líneas WRITE_ENABLE y READ_ENABLE.
//   * Todas las celdas comparten UNA sola línea de datos D_in/out.
//
// Ejemplo del video: 16 latches (4x4) con dirección de 4 bits.
//   Sin matriz: 16 entradas + 16 salidas = 32 cables.
//   Con matriz: 4 bits de dirección + WE + RE + 1 línea de datos.
//
// Las salidas del decodificador se reciben ya calculadas (row_sel/col_sel)
// para que varias matrices puedan compartir los mismos decodificadores
// (ver memory_top.sv).
// ============================================================================
`timescale 1ns/1ps

module memory_matrix #(
    parameter int ROWS = 4,
    parameter int COLS = 4
) (
    input  logic [ROWS-1:0] row_sel,       // salidas one-hot del decodificador de filas
    input  logic [COLS-1:0] col_sel,       // salidas one-hot del decodificador de columnas
    input  logic            write_enable,
    input  logic            read_enable,
    inout  wire             data_io        // D_in/out compartida
);
    genvar r, c;
    generate
        for (r = 0; r < ROWS; r++) begin : g_row
            for (c = 0; c < COLS; c++) begin : g_col
                memory_cell u_cell (
                    .row_sel      (row_sel[r]),
                    .col_sel      (col_sel[c]),
                    .write_enable (write_enable),
                    .read_enable  (read_enable),
                    .data_io      (data_io)
                );
            end
        end
    endgenerate

endmodule
